<?php
// Version: 2.0 RC2; Settings

global $settings;

// Important! Before editing these language files please read the text at the top of index.english.php.
$txt['theme_thumbnail_href'] = '';
$txt['theme_description'] = 'Le thème par défaut de l\'incarnation précédente de SMF, nom de code Core.<br /><br />Auteur : l\'Équipe Simple Machines';

?>